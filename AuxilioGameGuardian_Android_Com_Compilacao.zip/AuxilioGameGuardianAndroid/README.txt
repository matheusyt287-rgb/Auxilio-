AUXILIO GAME GUARDIAN — PROJETO ANDROID

O que contém:
- Interface HTML/CSS/JS futurista dentro de um app Android.
- Janela flutuante nativa arrastável, com minimizar, reabrir e fechar.
- Alternâncias visuais de Aimbot e Headshot, sem alterar nenhum jogo.
- Português/Inglês e painel de administrador demonstrativo.

COMO GERAR O APK:
1. Extraia o ZIP.
2. Abra a pasta AuxilioGameGuardian no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Vá em Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de debug costuma aparecer em app/build/outputs/apk/debug/app-debug.apk.

PERMISSÃO DE SOBREPOSIÇÃO:
Ao tocar em "Ativar sobreposição", o app abre as configurações Android para você permitir que Auxilio Game Guardian apareça sobre outros apps. Essa permissão é concedida pelo sistema Android, não pelo Chrome.

NOTAS:
- Este pacote é o código-fonte do projeto, não um APK já compilado.
- Compile com Android Studio/SDK compatível com compileSdk 35.
- A sobreposição é apenas um painel demonstrativo; Aimbot/Headshot não têm efeito no jogo.

COMPILAR USANDO O CELULAR COM GITHUB ACTIONS:
1. Extraia o ZIP e envie os arquivos do projeto para um repositório GitHub seu.
2. Certifique-se de incluir a pasta oculta .github/workflows/build-apk.yml.
3. Abra a aba Actions do repositório e permita Actions se for solicitado.
4. Escolha "Build Auxilio Game Guardian APK" e toque em "Run workflow".
5. Quando terminar com sucesso, abra a execução e baixe o artefato "Auxilio-Game-Guardian-APK".
6. Extraia o artefato baixado; dentro estará o APK de debug para instalar.

O build na nuvem depende de internet e de uma conta GitHub. Revise o código antes de publicar.
