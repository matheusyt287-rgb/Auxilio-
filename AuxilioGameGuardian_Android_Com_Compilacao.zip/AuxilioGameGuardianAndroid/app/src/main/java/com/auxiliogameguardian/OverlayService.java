package com.auxiliogameguardian;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class OverlayService extends Service {
    private WindowManager windowManager;
    private View panel;
    private WindowManager.LayoutParams params;
    private float downX, downY;
    private int startX, startY;
    private boolean aimOn = false, hsOn = false;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        buildPanel();
    }

    private GradientDrawable bg(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(24);
        d.setStroke(2, stroke);
        return d;
    }

    private TextView label(String text, int size) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(size);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(14, 10, 14, 10);
        return t;
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackground(bg(Color.rgb(25, 35, 54), Color.rgb(0, 220, 190)));
        return b;
    }

    private void buildPanel() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(12, 8, 12, 12);
        root.setBackground(bg(Color.rgb(8, 14, 27), Color.rgb(0, 220, 190)));
        root.setElevation(16);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("AUXILIO  •  DEMO", 14);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        Button close = makeButton("×");
        close.setOnClickListener(v -> stopSelf());
        header.addView(close, new LinearLayout.LayoutParams(48, 46));
        root.addView(header);

        TextView disclaimer = label("VISUAL APENAS • SEM EFEITO NO JOGO", 10);
        disclaimer.setTextColor(Color.rgb(0, 220, 190));
        root.addView(disclaimer);

        Button aim = makeButton("Aimbot visual: DESLIGADO");
        aim.setOnClickListener(v -> {
            aimOn = !aimOn;
            aim.setText("Aimbot visual: " + (aimOn ? "LIGADO" : "DESLIGADO"));
            Toast.makeText(this, "Modo demonstrativo", Toast.LENGTH_SHORT).show();
        });
        root.addView(aim);

        Button hs = makeButton("Headshot visual: DESLIGADO");
        hs.setOnClickListener(v -> {
            hsOn = !hsOn;
            hs.setText("Headshot visual: " + (hsOn ? "LIGADO" : "DESLIGADO"));
        });
        root.addView(hs);

        Button minimize = makeButton("Minimizar painel");
        minimize.setOnClickListener(v -> {
            if (panel != null) {
                windowManager.removeView(panel);
                panel = null;
                addBubble();
            }
        });
        root.addView(minimize);

        panel = root;
        params = new WindowManager.LayoutParams(
            dp(270), WindowManager.LayoutParams.WRAP_CONTENT,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = dp(18);
        params.y = dp(120);
        attachDrag(root);
        windowManager.addView(panel, params);
    }

    private void addBubble() {
        TextView bubble = label("AG", 14);
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackground(bg(Color.rgb(8, 14, 27), Color.rgb(0, 220, 190)));
        WindowManager.LayoutParams bubbleParams = new WindowManager.LayoutParams(
            dp(58), dp(58),
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = dp(12);
        bubbleParams.y = dp(180);
        bubble.setOnClickListener(v -> {
            try { windowManager.removeView(bubble); } catch (Exception ignored) {}
            buildPanel();
        });
        attachDrag(bubble, bubbleParams);
        windowManager.addView(bubble, bubbleParams);
        panel = bubble;
    }

    private void attachDrag(View view) { attachDrag(view, params); }
    private void attachDrag(View view, WindowManager.LayoutParams lp) {
        view.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                downX = e.getRawX(); downY = e.getRawY();
                startX = lp.x; startY = lp.y;
                return false;
            }
            if (e.getAction() == MotionEvent.ACTION_MOVE) {
                lp.x = startX + (int)(e.getRawX() - downX);
                lp.y = startY + (int)(e.getRawY() - downY);
                try { windowManager.updateViewLayout(v, lp); } catch (Exception ignored) {}
                return true;
            }
            return false;
        });
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override public void onDestroy() {
        if (panel != null) {
            try { windowManager.removeView(panel); } catch (Exception ignored) {}
            panel = null;
        }
        super.onDestroy();
    }
}
